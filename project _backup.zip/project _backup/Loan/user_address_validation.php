<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Finance management system</title>
      
        <!--
          - custom css link
        -->
        <link rel="stylesheet" href="./assets/css/style.css">
        <link rel="stylesheet" href="./assets/css/media_queries.css">
        <link rel="stylesheet" href="./assets/css/animation.css">
        <link rel="stylesheet" href="./assets/css/calculator_style">

      
        <!--
          - google font link
        -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link
          href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700;800;900&family=Roboto:wght@400;500&display=swap"
          rel="stylesheet">
       
     <style>
     .testimonials-right { position:absolute; padding: 30% 15px 0;  }
     
     .testimonials-card {
  position: relative;
  background: var(--white);
  border-radius: 8px;
  padding: 40px;
  box-shadow: 0 15px 30px hsla(0, 0%, 0%, 0.1);
}


     </style>





    </head>
<body>

  <div class="container" style="margin-top: 8%;" >

 <header>
      <nav class="navbar">

        <div class="navbar-brand">
          <img src="side logo.png" alt="Loan logo">
        </div>
        <h2 style="margin-right:50%" >Apply for personal loan</h2>
      </nav>

    </header>
 

    <!----------------------------------------form -------------------------------------------------->

    <!----------------------------------------form end-------------------------------------------------->

  



    <section class="">


      </div>

      <div class="testimonials-right" style="left:17%; margin-bottom: 50% ; top:-50%" >

        <div class="testimonials-card" style="left:-10% ;"  >

         

          <p class="testimonials-text">
            <form action="code.php" method="POST" enctype="multipart/form-data" >
              <h1>Loan Application</h1>
              <fieldset>
                <div class="testimonials-client">

                  <div class="client-img-box">
                    <img src="./assets/images/client.jpg" >
                  </div>
                  <div>
                    <!-- <div class="form-group"> -->
                    <lable>upload Your Aadhar Card</lable>
                    <inpute type="file" name="uploadaadhar" id="uploadaadhar" required >
                    <!-- </div> -->
                    <input type="file" id="uploadaadhar" name="uploadaadhar">
                    
                  </div><br>
                <legend>User Address Validation</legend>
                <label for="street_address">Street Address</label>
                <input type="text" name="street_address" required />
                <label for="city">City</label>
                <input type="text" name="city" required />
                <label for="state">State</label>
                <input type="text" name="state"required />
                <br/><br>
                <div><label for="Pin_code">Pin Code</label>
                <input type="text" name="Pin_code" placeholder="Pin_code" required />
                <br/><div>
              </fieldset>
            
              
              
            <button type="submit" name="save_user" >Submit</button>
 

            </form>
        
          </p>

          

          </div>
        </div>

      </div>

    </section>




    

</body>
</html>
