<?php

$server_name = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "loan_db";

$connection = mysqli_connect($server_name,$db_username,$db_password,$db_name);

if(!$connection)
{
    die("Connection failed: " . mysqli_connect_error());
    echo '
        <div class="container">
            <div class="row">
                <div class="col-md-8 mr-auto ml-auto text-center py-5 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h1 class="card-title bg-danger text-white"> Database Connection Failed </h1>
                            <h2 class="card-title"> Database Failure</h2>
                            <p class="card-text"> Please Check Your Database Connection.</p>
                            <a href="#" class="btn btn-primary">:( </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    ';
}


// $data=mysqli_connect($server_name,$db_username,$db_password,$db_name);
// if(data===false)
// {
//     die("connection error");
// }

//   if($_SERVER["REQUEST_METHOD"]=="POST")
// {
//     $username=$_POST["username"];
//     $password=$_POST["password"];
  
//    $sql="select * from login where username='".$username."' AND password='".$password." ' ";
  
//     $result=mysqli_query($data,$sql);
  
//     $row=mysqli_fetch_array($result);
  
//      if($row["usertype"]=="user")
//    {
//       echo "user";
//     }
//        elseif($row["usertype"]=="admin")
//     {
//       echo "admin";
//     }
//     else
//     {
//       echo "username or password incorrect";
//     }
// ?>