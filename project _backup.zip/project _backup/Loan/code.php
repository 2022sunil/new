<?php
include('database/security.php');

if(isset($_POST['registerbtn']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];

    $email_query = "SELECT * FROM register WHERE email='$email' ";
    $email_query_run = mysqli_query($connection, $email_query);
    if(mysqli_num_rows($email_query_run) > 0)
    {
        $_SESSION['status'] = "Email Already Taken. Please Try Another one.";
        $_SESSION['status_code'] = "error";
        header('Location: index.php?page=register.php');  
    }
    else
    {
        if($password === $cpassword)
        {
            $query = "INSERT INTO register (username,email,password) VALUES ('$username','$email','$password')";
            $query_run = mysqli_query($connection, $query);
            
            if($query_run)
            {
                // echo "Saved";
                $_SESSION['status'] = "Admin Profile Added";
                $_SESSION['status_code'] = "success";
                header('Location: index.php?page=register');
            }
            else 
            {
                $_SESSION['status'] = "Admin Profile Not Added";
                $_SESSION['status_code'] = "error";
                header('Location:index.php?page=register');  
            }
        }
        else 
        {
            $_SESSION['status'] = "Password and Confirm Password Does Not Match";
            $_SESSION['status_code'] = "warning";
            header('Location: index.php?page=register');  
        }
    }

}



if(isset($_POST['updatebtn']))
{
    $id = $_POST['edit_id'];
    $username = $_POST['edit_username'];
    $email = $_POST['edit_email'];
    $password = $_POST['edit_password'];

    $query = "UPDATE register SET username='$username', email='$email', password='$password' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: index.php?page=register'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: index.php?page=register'); 
    }
}








if(isset($_POST['edit_btn']))
{
    $id = $_POST['edit_id'];
    $username = $_POST['edit_username'];
    $email = $_POST['edit_email'];
    $password = $_POST['edit_password'];

    $query = "UPDATE register SET username='$username', email='$email', password='$password' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: index.php?page=register'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: index.php?page=register'); 
    }
}


if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM register WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
        header('Location: index.php?page=register'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
        header('Location: index.php?page=register'); 
    }   
}

if(isset($_POST['login_btn']))
{
    $email_login = $_POST['emaill']; 
    $password_login = $_POST['passwordd']; 

    $query = "SELECT * FROM users WHERE email='$email_login' AND password='$password_login' LIMIT 1";
    $query_run = mysqli_query($connection, $query);

   if(mysqli_fetch_array($query_run))
   {
        $_SESSION['username'] = $email_login;
        header('Location: index.php?page=home');
   } 
   else
   {
        $_SESSION['status'] = "Email / Password is Invalid";
        header('Location: login.php');
   }
    
}



// ---------------------------------------- user php ------------------------------------------------------//

if(isset($_POST['save_user']))
{
$first_name = $_POST['first_name'];
$middle_initial = $_POST['middle_initial']; 
$last_name = $_POST['last_name']; 
$email = $_POST['email']; 
$telephone = $_POST['telephone']; 
$address = $_POST['address']; 
$occupation = $_POST['occupation']; 
$company_name = $_POST['company_name']; 
$company_location = $_POST['company_location']; 
$loan_amount = $_POST['loan_amount']; 
$down_payment = $_POST['down_payment']; 
$name_of_cosigner = $_POST['name_of_cosigner']; 
$cosigner_occupation = $_POST['cosigner_occupation']; 
$street_address = $_POST['street_address'];
$city = $_POST['city'];
$state = $_POST['state'];
$Pin_code = $_POST['Pin_code'];
$uploadimage = $_FILES["uploadimage"]['name'];
$aadhar = $_FILES["aadhar"]['name'];
$idcard = $_FILES["idcard"]['name'];
$bank = $_FILES["bank"]['name'];
$account_number = $_POST['account_number'];
$ifsc_code = $_POST['ifsc_code'];
$upi_id = $_POST['upi_id'];

if(file_exists("upload/" . $_FILES["uploadimage"]["name"])) 
{
    $store =  $_FILES["uploadimage"]["name"];
    $_SESSION ['status']= "Image already exists. '.$store.'";
    header('Location: index.php');
}
else{
    if(file_exists("upload/" . $_FILES["aadhar"]["name"])) 
{
    $store =  $_FILES["aadhar"]["name"];
    $_SESSION ['status']= "Image already exists. '.$store.'";
    header('Location: index.php');
}
else{
if(file_exists("upload/" . $_FILES["idcard"]["name"])) 
{
    $store =  $_FILES["idcard"]["name"];
    $_SESSION ['status']= "Image already exists. '.$store.'";
    header('Location: index.php');
}
else{
    if(file_exists("upload/" . $_FILES["bank"]["name"])) 
    {
        $store =  $_FILES["bank"]["name"];
        $_SESSION ['status']= "Image already exists. '.$store.'";
        header('Location: index.php');
    }
    
else
{
       $query = "INSERT INTO loanuser (`first_name`,`middle_initial`,`last_name`,`email`,`telephone`,`address`,`occupation`,`company_name`,`company_location`,`loan_amount`, `down_payment`,`name_of_cosigner`,`cosigner_occupation`,`street_address`,`city`,`state`,`Pin_code`,`uploadimage`,`aadhar`,`idcard`,`bank`,`account_number`,`ifsc_code`,`upi_id`) VALUES ('$first_name','$middle_initial','$last_name','$email','$telephone','$address','$occupation','$company_name','$company_location','$loan_amount', '$down_payment','$name_of_cosigner','$cosigner_occupation','$street_address','$city','$state','$Pin_code','$uploadimage','$aadhar','$idcard','$bank','$account_number','$ifsc_code','$upi_id')";
       $query_run = mysqli_query($connection, $query);

       if($query_run)
       {
        
         move_uploaded_file($_FILES["uploadimage"]["tmp_name"], "upload/".$_FILES["uploadimage"][" name"]);
          $_SESSION['success'] = "Loan is Applyed";
          header('Location: ../project _backup/index.html');
       }
       if($query_run)
       {
        
         move_uploaded_file($_FILES["aadhar"]["tmp_name"], "upload/".$_FILES["aadhar"][" name"]);
          $_SESSION['success'] = "Loan is Applyed";
          header('Location: ../project _backup/index.html');
       }
       else
       {
          $_SESSION['success'] = "Loan is not Applyed";
          header('Location: ../project _backup/index.html');
       }
}

}
}
}
}

?>