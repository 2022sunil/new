
<style>
</style>
<nav id="sidebar" class='mx-lt-5 bg-warning' >
		
		<div class="sidebar-list">

		
                <!----------------------------------   navbar     --------------------------------------->
				<div id="sidebar" class="active">
        <div class="sidebar-wrapper active">
            <div class="sidebar-header">
                    
                        <div>
                            <a href="index.html"><img  src="blank.jpg"  alt="Logo" style="width: 236px;height: 48px;margin-top: 10%;margin-left: 5%;margin-bottom: 5%;margin-right: 5%;" srcset=""></a>
                        </div>              
            </div>
                <div class="sidebar-menu">
                    <ul class="menu">
                       
					
				<a href="index.php?page=home" class="nav-item "><i class="fa fa-home"></i> Home</a>
				<a href="index.php?page=loans" class="nav-item "><span class='icon-field'><i class="fa fa-file-invoice-dollar"></i></span> Loans</a>	
				<a href="index.php?page=payments" class="nav-item "><span class='icon-field'><i class="fa fa-money-bill"></i></span> Payments</a>
				<a href="index.php?page=borrowers" class="nav-item"><span class='icon-field'><i class="fa fa-user-friends"></i></span> Borrowers</a>
				<a href="index.php?page=plan" class="nav-item "><span class='icon-field'><i class="fa fa-list-alt"></i></span> Loan Plans</a>	
				<a href="index.php?page=loan_type" class="nav-item"><span class='icon-field'><i class="fa fa-th-list"></i></span> Loan Types</a>
				<a href="index.php?page=register" class="nav-item ">Add Admin</a>
				<a href="index.php?page=user" class="nav-item ">borrowers</a>
			</ul>
                </div>
        </div>
    </div>
			    <!----------------------------------   navbar     --------------------------------------->
				


				
				<?php if($_SESSION['login_type'] == 1): ?>
				<a href="index.php?page=users" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users"></i></span> Users</a>
				
			<?php endif; ?>
		</div>

</nav>
<script>
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
</script>
