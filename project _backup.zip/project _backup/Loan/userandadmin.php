{
  $username=$ POST["username"];
  $password=$_POSTrpassword"];

 $sql "select * from login where username='" $username "' AND password='" $password "

  $result mysqli_query($data,$sql);

  $row mysqli_fetch_array($result);

   ($row["usertype"] "user")

    echo "user";

     ($row["usertype"] "admin")

    echo "admin";

    echo "username or password incorrect;
}