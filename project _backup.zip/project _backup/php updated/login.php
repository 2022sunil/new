<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
</head>
<body>

<div class="container">

<div class="header">

<h2>Log In</h2>

<form action="login.php" method="post">
<div>
    <lable for="username">username :</lable>
    <input type="text" name="username" required>
</div>

<!-- <div>
    <lable for="email">Email : </lable>
    <input type="email" name="email" required>
</div> -->

<div>
    <lable for="password">password :</lable>
    <input type="password" name="password_1" required>
</div>

<!-- <div>
    <lable for="password">Confirm password : </lable>
    <input type="password" name="password_2" required>
</div> -->

<button type="submit" name="login_user"> submit </button>

<p> Not a user?<a href="registration.php"><b>Register Here</b></a></p>




</form>

</div>
    
</body>
</html>