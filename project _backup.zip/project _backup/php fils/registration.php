<?php include('server.php') ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
</head>
<body>
<form>
<div>
    <lable for="username">username :</lable>
    <input type="text" name="username"required>
</div>

<div>
    <lable for="email">Email : </lable>
    <input type="gmail" name="gmail"required>
</div>

<div>
    <lable for="password">password :</lable>
    <input type="password" name="password_1"required>
</div>

<div>
    <lable for="password">Confirm password : </lable>
    <input type="password" name="password_2"required>
</div>

<button type="submit"> submit </button>

<p>Already a user?<a href="login.php">Login</a></p>



</form>
    
</body>
</html>